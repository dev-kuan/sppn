import './bootstrap';

import Alpine from 'alpinejs';
import ApexCharts from 'apexcharts'

window.Alpine = Alpine;
window.ApexCharts = ApexCharts;

Alpine.start();
